function like_alert() {
    alert("Ninja was liked");
};
function remove_add_definition() {
    document.getElementById("btn").remove();
}; 
function change_text() {
    document.getElementById("login").innerHTML = "Logout";
};